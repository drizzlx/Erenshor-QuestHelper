# Quest Helper

Adds quest markers ! and ? above NPC names like in World of Warcraft.

## Installation
- Install [BepInEx Mod Pack](https://thunderstore.io/package/bbepis/BepInExPack/)
- Download the latest [release](https://github.com/drizzlx/Erenshor-QuestHelper/releases)
- Extract the files into *Erenshor\BepInEx\plugins\drizzlx-ErenshorQuestHelper* folder

## Patch Notes
1.0.1
- Performance improvements.
- Bug fixes for errors seen in logs related to NULL objects.